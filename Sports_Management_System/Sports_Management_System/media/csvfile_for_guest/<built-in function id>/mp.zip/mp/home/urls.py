from django.conf.urls import url, include
from django.contrib import admin
# from django.urls import include
from home import views

urlpatterns = [
    url(r'', views.home, name='home'),
    url(r'contact', views.contact, name='contact'),
]